package EjerciciosDiseño;

public class Discos extends Publicación {
	private double duraciónMinutos;

	public Discos() {
		// TODO Auto-generated constructor stub
	}

	public Discos(String titulo, double precio,double duraciónMinutos) {
		super(titulo, precio);
		this.duraciónMinutos=duraciónMinutos;
		
	}

	public double getDuraciónMinutos() {
		return duraciónMinutos;
	}

	public void setDuraciónMinutos(double duraciónMinutos) {
		this.duraciónMinutos = duraciónMinutos;
	}

	@Override
	public String toString() {
		return "Discos [duración Minutos = " + duraciónMinutos + "]";
	}
	

}
