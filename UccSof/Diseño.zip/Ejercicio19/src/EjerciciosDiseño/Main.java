package EjerciciosDiseño;
import java.util.Scanner;

public class Main {
	public static void main(String[]args) {
		Scanner scanner = new Scanner(System.in);
		
        System.out.println("Dijite nombre libro:");
        String tituloLibro = scanner.nextLine();

        System.out.println("dijite el precio del libro:");
        float precioLibro = scanner.nextFloat();

        System.out.println("dijete las paginas del libro:");
        int paginasLibro = scanner.nextInt();

        System.out.println("dije year publicacion libro");
        int anioPublicacionLibro = scanner.nextInt();

        Libros libro = new Libros(tituloLibro, precioLibro, paginasLibro, anioPublicacionLibro);

        scanner.nextLine(); 
        System.out.println("dije nombre disco");
        String tituloDisco = scanner.nextLine();

        System.out.println("dijite  el precio del disco:");
        float precioDisco = scanner.nextFloat();

        System.out.println("tiempo de duracion en minutos:");
        float duracionDisco = scanner.nextFloat();

        Discos disco = new Discos(tituloDisco, precioDisco, duracionDisco);

        System.out.println("Datos del libros:");
        System.out.println(libro);

        System.out.println("Datos del discos:");
        System.out.println(disco);

        scanner.close();
		
		
	}

}
