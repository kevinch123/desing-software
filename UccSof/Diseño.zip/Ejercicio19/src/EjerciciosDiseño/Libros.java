package EjerciciosDiseño;

public class Libros extends Publicación {
	private int numeroPaginas;
	private int añoPublicación;

	public Libros() {
		// TODO Auto-generated constructor stub
	}

	public Libros(String titulo, double precio,int numeroPaginas,int añoPublicación) {
		super(titulo, precio);
		this.añoPublicación=añoPublicación;
		this.numeroPaginas=numeroPaginas;
	}

	public int getNumeroPaginas() {
		return numeroPaginas;
	}

	public void setNumeroPaginas(int numeroPaginas) {
		this.numeroPaginas = numeroPaginas;
	}

	public int getAñoPublicación() {
		return añoPublicación;
	}

	public void setAñoPublicación(int añoPublicación) {
		this.añoPublicación = añoPublicación;
	}

	@Override
	public String toString() {
		return "Libros [numero Paginas = " + numeroPaginas + ", añoPublicación=" + añoPublicación + "]";
	}
	
	

}
