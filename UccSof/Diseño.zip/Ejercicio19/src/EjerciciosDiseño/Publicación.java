package EjerciciosDiseño;

public class Publicación {
	private String titulo;
	private Double precio;

	public Publicación() {
		// TODO Auto-generated constructor stub
	}
	public Publicación(String titulo,double precio) {
		this.titulo=titulo;
		this.precio=precio;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public Double getPrecio() {
		return precio;
	}
	public void setPrecio(Double precio) {
		this.precio = precio;
	}
	@Override
	public String toString() {
		return "Publicación [titulo=" + titulo + ", precio=" + precio + "]";
	}
	

}
