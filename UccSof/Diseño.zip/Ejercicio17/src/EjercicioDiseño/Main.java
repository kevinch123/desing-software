package EjercicioDiseño;

public class Main {

	public static void main(String[]args) {
		
		Circle circle=new Circle();
		Rectangle rectangle=new Rectangle();
		Square squeare=new Square();
		
		System.out.println(circle);
		System.out.println(rectangle);
		System.out.println(squeare);
		
	}

}
