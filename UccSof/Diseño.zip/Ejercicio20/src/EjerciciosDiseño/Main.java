package EjerciciosDiseño;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
    	
    	 Scanner scanner = new Scanner(System.in);

         System.out.println("dijite el nombre:");
         String nombre = scanner.nextLine();

         System.out.println("dijite el primer apellido:");
         String primerApellido = scanner.nextLine();

         System.out.println("dijite el segundo apellido:");
         String segundoApellido = scanner.nextLine();

         Nombre miNombre = new Nombre(nombre, primerApellido, segundoApellido);

         System.out.println("dijite la calle:");
         String calle = scanner.nextLine();

         System.out.println("dijite la ciudad:");
         String ciudad = scanner.nextLine();

         System.out.println("dijite el municipio:");
         String municipio = scanner.nextLine();

         System.out.println("dijite el código postal:");
         String codigoPostal = scanner.nextLine();

         Direccion miDireccion = new Direccion(nombre, primerApellido, segundoApellido, calle, ciudad, municipio, codigoPostal);

         System.out.println("\nInformación personal:");
         System.out.println(miNombre);

         System.out.println("\nInformación de la Dirección:");
         System.out.println(miDireccion);

         scanner.close();

    }
}
