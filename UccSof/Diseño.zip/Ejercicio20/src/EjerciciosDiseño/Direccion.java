package EjerciciosDiseño;

public class Direccion extends Nombre {
	private String calle;
	private String ciudad;
	private String municipio;
	private String codigoPostal;

	public Direccion() {
		// TODO Auto-generated constructor stub
	}

	public Direccion(String nombre, String primerApellido, String segundoApellido,String calle, String ciudad, String municipio, String codigoPostal) {
		super(nombre, primerApellido, segundoApellido);
		this.calle = calle;
		this.ciudad = ciudad;
		this.municipio = municipio;
		this.codigoPostal = codigoPostal;
	}

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getMunicipio() {
		return municipio;
	}

	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}
	
    public void nuevaDireccion(String calle, String ciudad, String municipio, String codigoPostal) {
        this.calle = calle;
        this.ciudad = ciudad;
        this.municipio = municipio;
        this.codigoPostal = codigoPostal;
    }

    public void nuevoNombre(String nombre, String primerApellido, String segundoApellido) {
        super.setNombre(nombre);
        super.setPrimerApellido(primerApellido);
        super.setSegundoApellido(segundoApellido);
    }

	@Override
	public String toString() {
		
		return "Direccion [calle=" + calle + ", ciudad=" + ciudad + ", municipio=" + municipio + ", codigoPostal="
				+ codigoPostal + "]";
	}
	

	

}
