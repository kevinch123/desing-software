package EjerciciosDiseño;

public class Main {
	public static void main(String[] args) {
    Student student = new Student("Kevin", "Catambuco", "Ingenieria de software", 2, 5000000);
    
    Staff staff = new Staff("Camilo", "Sector san martin", "UCC", 5.000);
    
    System.out.println("Information student:");
    System.out.println(student); 
   
    System.out.println("\n Information staff:");
    System.out.println(staff); 
 
 

	}
}
