package EjerciciosDiseño;
import java.util.Scanner;
public class Main {

	 public static void main(String[] args) {
	       Scanner scanner = new Scanner(System.in);

	        System.out.print("Ingrese el radio del círculo: ");
	        double radioCirculo = scanner.nextDouble();
	        Circulo circulo = new Circulo(radioCirculo);
	        System.out.println("Área del círculo: " + circulo.area());
	        System.out.println("Circunferencia del círculo: " + circulo.circunferencia());

	        System.out.print("Ingrese el radio del cilindro: ");
	        double radioCilindro = scanner.nextDouble();
	        System.out.print("Ingrese la altura del cilindro: ");
	        double alturaCilindro = scanner.nextDouble();
	        Cilindro cilindro = new Cilindro(radioCilindro, alturaCilindro);
	        System.out.println("Volumen del cilindro: " + cilindro.volumen());

	        scanner.close();
	 }
}
