package EjerciciosDiseño;

public class CilindroHueco extends Cilindro {

	private double radioInterior;

    public CilindroHueco(double radioExterior, double radioInterior, double altura) {
        super(radioExterior, altura);
        this.radioInterior = radioInterior;
    }

    public double getRadioInterior() {
        return radioInterior;
    }

    public void setRadioInterior(double radioInterior) {
        this.radioInterior = radioInterior;
    }

    @Override
    public double volumen() {
        double volumenExterior = super.volumen();
        double volumenInterior = Math.PI * Math.pow(radioInterior, 2) * getAltura();
        return volumenExterior - volumenInterior;
    }

}
