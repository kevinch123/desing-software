package EjerciciosDiseño;

public class Main {
	public static void main(String[]args) {
		Cylinder cylinder1 = new Cylinder();
		double miVolumen = cylinder1.getVolumen();
		System.out.println("Volume of cylinder1: " + miVolumen);
	}


}
