package EjercicioDiseño;

public class Main {
	public static void main(String[]args) {
		Animal animal= new Animal("Animal");
		Mammal mammal=new Mammal("Mammal");
		Cat cat = new Cat("Michi");
        Dog dog = new Dog("perrito");
        
        System.out.println(animal);
        System.out.println(mammal);
        System.out.println(cat);
        System.out.println(dog);

        cat.greets();
        dog.greets();
		dog.greets(dog);
	}


}
